from functools import reduce

numeros = [2, 64, 14, 10, 4, 66]

numeros_pares = filter(lambda x: x % 2 == 0, numeros)

suma_de_numeros_pares = reduce(lambda x, y: x + y, numeros_pares)

print("La suma de los números pares es:", suma_de_numeros_pares)