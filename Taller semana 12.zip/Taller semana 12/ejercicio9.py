lista_original = [1, 2, 3, 4, 5]

lista_cuadrados = list(map(lambda x: x**2, lista_original))

print("Lista original:", lista_original)
print("Lista con elementos elevados al cuadrado:", lista_cuadrados)
