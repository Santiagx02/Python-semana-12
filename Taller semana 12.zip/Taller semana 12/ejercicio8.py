from functools import reduce

numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

numeros_pares = filter(lambda x: x % 2 == 0, numeros)

producto = reduce(lambda x, y: x * y, numeros_pares)

print("El producto de los números pares es:", producto)