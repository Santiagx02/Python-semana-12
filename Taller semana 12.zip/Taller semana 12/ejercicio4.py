from functools import reduce

lista_numeros = [10, 5, 20, 8, 15]
valor_limite = 10 

elementos_mayores = filter(lambda x: x > valor_limite, lista_numeros)

cantidad_elementos_mayores = reduce(lambda acc, _: acc + 1, elementos_mayores, 0)

print("La cantidad de elementos mayores que", valor_limite, "es:", cantidad_elementos_mayores)
