from functools import reduce

# Definir la lista de números
lista_numeros = [1, 2, 3, 4, 5]

suma = reduce(lambda x, y: x + y, lista_numeros)

print("La suma de todos los elementos de la lista es:", suma)
