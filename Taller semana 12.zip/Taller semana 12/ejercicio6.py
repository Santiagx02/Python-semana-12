# Definir la lista de cadenas
list_cadena = ["1", "2", "3", "4", "5"]

list_entero = list(map(lambda x: int(x), list_cadena))

print("Lista de cadenas:", list_cadena)
print("Lista de enteros:", list_entero)
