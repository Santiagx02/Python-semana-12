numeros = [1, 2, 3, 4, 5]

numeros_duplicados = map(lambda x: x * 2, numeros)

numeros_duplicados = list(numeros_duplicados)

print("La lista duplicada es:", numeros_duplicados)