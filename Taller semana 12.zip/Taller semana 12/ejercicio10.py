from functools import reduce

lista_cadenas = ["Hoola", "Saludos ", "Desde", "Colombia ", "Tierra", "Querida"]

cadena_concatenada = reduce(lambda x, y: x + y, lista_cadenas)

print("Cadena concatenada:", cadena_concatenada)
