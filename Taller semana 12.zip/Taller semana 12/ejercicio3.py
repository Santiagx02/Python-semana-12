from functools import reduce

numbers = [1, 5, 3, 8, 2]

max_number = reduce(lambda x, y: x if x > y else y, numbers)

print("El máximo elemento de la lista es:", max_number)